package com.tanzim.oranow

import com.tanzim.oranow.data.Category
import com.tanzim.oranow.data.TaskEntity
import com.tanzim.oranow.data.TaskWithSubtasks
import com.tanzim.oranow.domain.TaskLogic
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId

class TaskLogicTest {

    private val zone = ZoneId.of("UTC")
    private val today = LocalDate.of(2026, 10, 18)

    // "Now" is Sunday 18 Oct 2026, 12:00 UTC
    private val now = today.atTime(12, 0).atZone(zone).toInstant().toEpochMilli()

    private fun millis(date: LocalDate, time: LocalTime) =
        date.atTime(time).atZone(zone).toInstant().toEpochMilli()

    private fun task(
        id: Long,
        date: LocalDate?,
        time: LocalTime? = null,
        done: Boolean = false,
        completedAt: Long? = null,
        category: Category = Category.PERSONAL
    ) = TaskWithSubtasks(
        TaskEntity(
            id = id,
            title = "task $id",
            dueAt = TaskLogic.computeDueAt(date, time, zone),
            hasDueTime = date != null && time != null,
            isCompleted = done,
            completedAt = completedAt,
            category = category
        ),
        emptyList()
    )

    @Test
    fun bucketsPartitionTasksCorrectly() {
        val all = listOf(
            task(1, today),                                  // date only, today -> Today
            task(2, today.minusDays(1)),                     // yesterday -> Overdue
            task(3, today.plusDays(1)),                      // tomorrow -> Upcoming
            task(4, null),                                   // no date -> Upcoming
            task(5, today, LocalTime.of(9, 0)),              // today 09:00, already passed -> Overdue
            task(6, today, LocalTime.of(18, 0)),             // today 18:00 -> Today
            task(7, today, done = true, completedAt = now)   // done -> Completed only
        )
        val b = TaskLogic.bucketize(all, now, zone)

        assertEquals(listOf(6L, 1L), b.today.map { it.task.id })
        assertEquals(setOf(2L, 5L), b.overdue.map { it.task.id }.toSet())
        assertEquals(setOf(3L, 4L), b.upcoming.map { it.task.id }.toSet())
        assertEquals(listOf(7L), b.completed.map { it.task.id })
        assertEquals(all.size, b.today.size + b.overdue.size + b.upcoming.size + b.completed.size)
    }

    @Test
    fun dateOnlyTaskDueTodayIsNotOverdueUntilTomorrow() {
        val t = task(1, today).task
        assertFalse(TaskLogic.isOverdue(t.dueAt, t.isCompleted, now))
        val tomorrowMorning = millis(today.plusDays(1), LocalTime.of(0, 1))
        assertTrue(TaskLogic.isOverdue(t.dueAt, t.isCompleted, tomorrowMorning))
    }

    @Test
    fun dailyProgressCountsDueTodayAndCompletedToday() {
        val all = listOf(
            task(1, today, done = true, completedAt = now),   // due today, done
            task(2, today),                                   // due today, open
            task(3, null, done = true, completedAt = now),    // no date but finished today
            task(4, today.minusDays(3), done = true, completedAt = millis(today.minusDays(2), LocalTime.NOON)) // not today
        )
        val p = TaskLogic.dailyProgress(all, now, zone)
        assertEquals(3, p.total)
        assertEquals(2, p.done)
    }

    @Test
    fun streakCountsConsecutiveDaysWithCompletions() {
        fun done(id: Long, daysAgo: Long) =
            task(id, null, done = true, completedAt = millis(today.minusDays(daysAgo), LocalTime.NOON))

        val withToday = listOf(done(1, 0), done(2, 1), done(3, 2), done(4, 4))
        assertEquals(3, TaskLogic.stats(withToday, now, zone).streak)

        val noToday = listOf(done(1, 1), done(2, 2))
        assertEquals(2, TaskLogic.stats(noToday, now, zone).streak)

        val gap = listOf(done(1, 3))
        assertEquals(0, TaskLogic.stats(gap, now, zone).streak)
    }

    @Test
    fun statsLast7DaysHasSevenEntriesEndingToday() {
        val s = TaskLogic.stats(listOf(task(1, today, done = true, completedAt = now)), now, zone)
        assertEquals(7, s.last7.size)
        assertEquals(today, s.last7.last().date)
        assertEquals(1, s.last7.last().count)
        assertEquals(1f, s.completionRate, 0.0001f)
    }

    @Test
    fun reminderTimeIsOffsetFromDueTimeOrNineAm() {
        val date = LocalDate.of(2026, 10, 20)
        assertEquals(
            millis(date, LocalTime.of(16, 0)),
            TaskLogic.computeRemindAt(date, LocalTime.of(17, 0), 60, zone)
        )
        assertEquals(
            millis(date, LocalTime.of(8, 0)),
            TaskLogic.computeRemindAt(date, null, 60, zone)
        )
        assertEquals(null, TaskLogic.computeRemindAt(null, null, 10, zone))
        assertEquals(null, TaskLogic.computeRemindAt(date, null, null, zone))
    }

    @Test
    fun searchMatchesTitleNotesCategoryAndSubtasks() {
        val item = TaskWithSubtasks(
            TaskEntity(id = 1, title = "Buy milk", notes = "organic", category = Category.SHOPPING),
            listOf(com.tanzim.oranow.data.SubtaskEntity(id = 1, taskId = 1, title = "check expiry"))
        )
        assertTrue(TaskLogic.matches(item, "MILK"))
        assertTrue(TaskLogic.matches(item, "organic"))
        assertTrue(TaskLogic.matches(item, "shopping"))
        assertTrue(TaskLogic.matches(item, "expiry"))
        assertFalse(TaskLogic.matches(item, "invoice"))
        assertTrue(TaskLogic.matches(item, "   "))
    }

    @Test
    fun dueLabelUsesFriendlyDayNames() {
        val dueToday = TaskLogic.computeDueAt(today, null, zone)!!
        assertEquals("Today", TaskLogic.dueLabel(dueToday, false, now, zone))
        val dueTomorrow = TaskLogic.computeDueAt(today.plusDays(1), null, zone)!!
        assertEquals("Tomorrow", TaskLogic.dueLabel(dueTomorrow, false, now, zone))
        val dueYesterday = TaskLogic.computeDueAt(today.minusDays(1), null, zone)!!
        assertEquals("Yesterday", TaskLogic.dueLabel(dueYesterday, false, now, zone))
    }
}
