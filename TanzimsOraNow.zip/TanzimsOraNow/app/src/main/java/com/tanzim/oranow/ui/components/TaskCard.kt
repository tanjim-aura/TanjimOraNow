package com.tanzim.oranow.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessTime
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.tanzim.oranow.data.SubtaskEntity
import com.tanzim.oranow.data.TaskWithSubtasks
import com.tanzim.oranow.domain.TaskLogic
import com.tanzim.oranow.ui.color
import com.tanzim.oranow.ui.icon
import java.time.ZoneId

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TaskCard(
    item: TaskWithSubtasks,
    now: Long,
    onToggle: () -> Unit,
    onClick: () -> Unit,
    onDelete: () -> Unit,
    onToggleSubtask: (SubtaskEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val task = item.task
    val scheme = MaterialTheme.colorScheme
    val overdue = TaskLogic.isOverdue(task.dueAt, task.isCompleted, now)
    val priorityColor = task.priority.color()
    var menuOpen by remember { mutableStateOf(false) }

    val subtasks = remember(item.subtasks) { item.subtasks.sortedBy { it.position } }
    val subtasksDone = subtasks.count { it.isDone }
    val contentAlpha by animateFloatAsState(
        targetValue = if (task.isCompleted) 0.55f else 1f,
        label = "taskAlpha"
    )
    val dueText = task.dueAt?.let {
        TaskLogic.dueLabel(it, task.hasDueTime, now, ZoneId.systemDefault())
    }

    Card(
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = scheme.surfaceContainerLow),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        border = BorderStroke(1.dp, scheme.outlineVariant.copy(alpha = 0.7f))
    ) {
        Row(Modifier.height(IntrinsicSize.Min)) {
            // Priority stripe
            Box(
                Modifier
                    .width(5.dp)
                    .fillMaxHeight()
                    .background(priorityColor.copy(alpha = if (task.isCompleted) 0.35f else 1f))
            )
            Column(
                Modifier
                    .weight(1f)
                    .padding(start = 8.dp, end = 4.dp, top = 8.dp, bottom = 10.dp)
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    CompleteCheck(
                        checked = task.isCompleted,
                        color = priorityColor,
                        onClick = onToggle
                    )
                    Column(
                        Modifier
                            .weight(1f)
                            .padding(top = 10.dp, start = 4.dp)
                    ) {
                        Text(
                            task.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = scheme.onSurface.copy(alpha = contentAlpha),
                            textDecoration = if (task.isCompleted) TextDecoration.LineThrough else null,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (task.notes.isNotBlank()) {
                            Text(
                                task.notes,
                                style = MaterialTheme.typography.bodySmall,
                                color = scheme.onSurfaceVariant.copy(alpha = contentAlpha),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                        FlowRow(
                            modifier = Modifier.padding(top = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            MetaChip(task.category.label, task.category.icon(), task.category.color())
                            if (dueText != null) {
                                MetaChip(
                                    dueText,
                                    Icons.Rounded.AccessTime,
                                    if (overdue) scheme.error else scheme.onSurfaceVariant
                                )
                            }
                            if (subtasks.isNotEmpty()) {
                                MetaChip(
                                    "$subtasksDone/${subtasks.size}",
                                    Icons.Rounded.Check,
                                    scheme.secondary
                                )
                            }
                            if (task.remindAt != null && !task.isCompleted) {
                                MetaChip("Reminder", Icons.Rounded.Notifications, scheme.tertiary)
                            }
                        }
                    }
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(
                                Icons.Rounded.MoreVert,
                                contentDescription = "More options",
                                tint = scheme.onSurfaceVariant
                            )
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("Edit") },
                                leadingIcon = { Icon(Icons.Rounded.Edit, contentDescription = null) },
                                onClick = {
                                    menuOpen = false
                                    onClick()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Delete", color = scheme.error) },
                                leadingIcon = {
                                    Icon(
                                        Icons.Rounded.Delete,
                                        contentDescription = null,
                                        tint = scheme.error
                                    )
                                },
                                onClick = {
                                    menuOpen = false
                                    onDelete()
                                }
                            )
                        }
                    }
                }

                if (subtasks.isNotEmpty()) {
                    LinearProgressIndicator(
                        progress = { subtasksDone.toFloat() / subtasks.size },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 8.dp, end = 12.dp, top = 6.dp)
                            .height(4.dp),
                        color = scheme.secondary,
                        trackColor = scheme.secondary.copy(alpha = 0.15f)
                    )
                    subtasks.forEach { sub ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .heightIn(min = 40.dp)
                                .clip(MaterialTheme.shapes.small)
                                .clickable { onToggleSubtask(sub) }
                                .padding(start = 4.dp, end = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = sub.isDone,
                                onCheckedChange = { onToggleSubtask(sub) }
                            )
                            Text(
                                sub.title,
                                style = MaterialTheme.typography.bodyMedium,
                                color = scheme.onSurface.copy(alpha = if (sub.isDone) 0.5f else 0.9f),
                                textDecoration = if (sub.isDone) TextDecoration.LineThrough else null,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CompleteCheck(checked: Boolean, color: Color, onClick: () -> Unit) {
    val fill by animateColorAsState(
        targetValue = if (checked) color else Color.Transparent,
        label = "checkFill"
    )
    val ringColor by animateColorAsState(
        targetValue = if (checked) color else MaterialTheme.colorScheme.outline,
        label = "checkRing"
    )
    Box(
        Modifier
            .size(48.dp)
            .clip(CircleShape)
            .clickable(role = Role.Checkbox, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier
                .size(26.dp)
                .clip(CircleShape)
                .background(fill)
                .border(2.dp, ringColor, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            AnimatedVisibility(
                visible = checked,
                enter = scaleIn() + fadeIn(),
                exit = scaleOut() + fadeOut()
            ) {
                Icon(
                    Icons.Rounded.Check,
                    contentDescription = "Completed",
                    modifier = Modifier.size(17.dp),
                    tint = Color.White
                )
            }
        }
    }
}

@Composable
private fun MetaChip(label: String, icon: ImageVector, color: Color) {
    Row(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.12f))
            .padding(horizontal = 8.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(13.dp), tint = color)
        Spacer(Modifier.width(4.dp))
        Text(label, style = MaterialTheme.typography.labelMedium, color = color, maxLines = 1)
    }
}
