package com.tanzim.oranow.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.FitnessCenter
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.ShoppingCart
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Work
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.tanzim.oranow.data.Category
import com.tanzim.oranow.data.Priority
import com.tanzim.oranow.domain.Buckets
import com.tanzim.oranow.data.TaskWithSubtasks
import com.tanzim.oranow.ui.theme.PriorityHigh
import com.tanzim.oranow.ui.theme.PriorityLow
import com.tanzim.oranow.ui.theme.PriorityMedium

fun Priority.color(): Color = when (this) {
    Priority.HIGH -> PriorityHigh
    Priority.MEDIUM -> PriorityMedium
    Priority.LOW -> PriorityLow
}

fun Category.icon(): ImageVector = when (this) {
    Category.PERSONAL -> Icons.Rounded.Person
    Category.WORK -> Icons.Rounded.Work
    Category.STUDY -> Icons.Rounded.School
    Category.HEALTH -> Icons.Rounded.FitnessCenter
    Category.SHOPPING -> Icons.Rounded.ShoppingCart
    Category.FINANCE -> Icons.Rounded.AccountBalanceWallet
    Category.OTHER -> Icons.Rounded.Star
}

fun Category.color(): Color = when (this) {
    Category.PERSONAL -> Color(0xFF7C6CF0)
    Category.WORK -> Color(0xFF3B82F6)
    Category.STUDY -> Color(0xFF14B8A6)
    Category.HEALTH -> Color(0xFF22C55E)
    Category.SHOPPING -> Color(0xFFF97316)
    Category.FINANCE -> Color(0xFF0EA5E9)
    Category.OTHER -> Color(0xFF94A3B8)
}

/** The four list sections shown on the Tasks screen. */
enum class Section(val label: String) {
    Today("Today"),
    Upcoming("Upcoming"),
    Completed("Completed"),
    Overdue("Overdue")
}

fun Section.items(buckets: Buckets): List<TaskWithSubtasks> = when (this) {
    Section.Today -> buckets.today
    Section.Upcoming -> buckets.upcoming
    Section.Completed -> buckets.completed
    Section.Overdue -> buckets.overdue
}
