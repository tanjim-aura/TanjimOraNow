package com.tanzim.oranow.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DateRange
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Today
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.tanzim.oranow.R
import com.tanzim.oranow.domain.DailyProgress
import com.tanzim.oranow.ui.Section
import com.tanzim.oranow.ui.TaskViewModel
import com.tanzim.oranow.ui.UiState
import com.tanzim.oranow.ui.components.ContentFrame
import com.tanzim.oranow.ui.components.EmptyState
import com.tanzim.oranow.ui.components.ProgressRing
import com.tanzim.oranow.ui.components.SectionHeader
import com.tanzim.oranow.ui.components.TaskActions
import com.tanzim.oranow.ui.components.TaskCard
import com.tanzim.oranow.ui.theme.BrandGradient
import com.tanzim.oranow.ui.theme.PriorityHigh
import com.tanzim.oranow.ui.theme.PriorityLow
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun HomeScreen(
    state: UiState,
    actions: TaskActions,
    onOpenSection: (Section) -> Unit,
    onOpenSettings: () -> Unit,
    padding: PaddingValues
) {
    val buckets = state.buckets

    ContentFrame {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 20.dp,
                end = 20.dp,
                top = padding.calculateTopPadding() + 12.dp,
                bottom = padding.calculateBottomPadding() + 96.dp
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item(key = "header") { Header(onOpenSettings) }
            item(key = "hero") { HeroCard(state.progress, state.stats.streak) }
            item(key = "tiles") {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StatTile(
                            "Overdue", buckets.overdue.size, PriorityHigh, Icons.Rounded.Warning,
                            { onOpenSection(Section.Overdue) }, Modifier.weight(1f)
                        )
                        StatTile(
                            "Today", buckets.today.size, MaterialTheme.colorScheme.primary,
                            Icons.Rounded.Today, { onOpenSection(Section.Today) }, Modifier.weight(1f)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StatTile(
                            "Upcoming", buckets.upcoming.size, MaterialTheme.colorScheme.secondary,
                            Icons.Rounded.DateRange, { onOpenSection(Section.Upcoming) }, Modifier.weight(1f)
                        )
                        StatTile(
                            "Completed", buckets.completed.size, PriorityLow,
                            Icons.Rounded.CheckCircle, { onOpenSection(Section.Completed) }, Modifier.weight(1f)
                        )
                    }
                }
            }

            if (buckets.overdue.isNotEmpty()) {
                item(key = "overdue-header") {
                    SectionHeader("Needs attention", actionLabel = "See all") {
                        onOpenSection(Section.Overdue)
                    }
                }
                items(buckets.overdue.take(3), key = { it.task.id }) { item ->
                    TaskCard(
                        item = item,
                        now = state.now,
                        onToggle = { actions.onToggle(item) },
                        onClick = { actions.onEdit(item) },
                        onDelete = { actions.onDelete(item) },
                        onToggleSubtask = actions.onToggleSubtask,
                        modifier = Modifier.animateItem()
                    )
                }
            }

            item(key = "today-header") {
                SectionHeader(
                    "Today",
                    actionLabel = if (buckets.today.size > 5) "See all" else null,
                    onAction = { onOpenSection(Section.Today) }
                )
            }
            if (buckets.today.isEmpty()) {
                item(key = "today-empty") {
                    if (state.all.isEmpty()) {
                        EmptyState(
                            icon = Icons.Rounded.Today,
                            title = "A blank canvas",
                            message = "Tap “New task” to add your first task and set a reminder."
                        )
                    } else {
                        EmptyState(
                            icon = Icons.Rounded.CheckCircle,
                            title = "Nothing left for today",
                            message = "Enjoy the free time, or plan something for later."
                        )
                    }
                }
            } else {
                items(buckets.today.take(5), key = { it.task.id }) { item ->
                    TaskCard(
                        item = item,
                        now = state.now,
                        onToggle = { actions.onToggle(item) },
                        onClick = { actions.onEdit(item) },
                        onDelete = { actions.onDelete(item) },
                        onToggleSubtask = actions.onToggleSubtask,
                        modifier = Modifier.animateItem()
                    )
                }
            }
        }
    }
}

@Composable
private fun Header(onOpenSettings: () -> Unit) {
    val greeting = remember {
        when (LocalTime.now().hour) {
            in 5..11 -> "Good morning"
            in 12..16 -> "Good afternoon"
            in 17..21 -> "Good evening"
            else -> "Hello, night owl"
        }
    }
    val dateText = remember {
        LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, MMMM d", Locale.getDefault()))
    }
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                greeting,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                stringResource(R.string.app_name),
                style = MaterialTheme.typography.headlineMedium
            )
            Text(
                dateText,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        IconButton(onClick = onOpenSettings) {
            Icon(Icons.Rounded.Settings, contentDescription = "Settings")
        }
    }
}

@Composable
private fun HeroCard(progress: DailyProgress, streak: Int) {
    val percent = (progress.fraction * 100).roundToInt()
    val brush = Brush.linearGradient(BrandGradient)
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(brush)
            .padding(22.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ProgressRing(
                progress = progress.fraction,
                color = Color.White,
                trackColor = Color.White.copy(alpha = 0.25f),
                diameter = 104.dp,
                strokeWidth = 11.dp
            ) {
                Text(
                    "$percent%",
                    style = MaterialTheme.typography.headlineSmall,
                    color = Color.White
                )
            }
            Spacer(Modifier.width(20.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "Today’s progress",
                    style = MaterialTheme.typography.labelLarge,
                    color = Color.White.copy(alpha = 0.8f)
                )
                Text(
                    if (progress.total == 0) "No tasks today" else "${progress.done} of ${progress.total} done",
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    motivation(progress),
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.92f)
                )
                if (streak > 0) {
                    Spacer(Modifier.height(10.dp))
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(50))
                            .background(Color.White.copy(alpha = 0.2f))
                            .padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Rounded.LocalFireDepartment,
                            contentDescription = null,
                            tint = Color(0xFFFFD166),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            "$streak-day streak",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

private fun motivation(p: DailyProgress): String = when {
    p.total == 0 -> "Add a task to get today started."
    p.done == p.total -> "All done. Enjoy the rest of your day!"
    p.fraction >= 0.5f -> "Over halfway there. Keep going!"
    p.done > 0 -> "Nice start. One at a time."
    else -> "A fresh day. Pick the first one."
}

@Composable
private fun StatTile(
    label: String,
    count: Int,
    color: Color,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onClick,
        modifier = modifier,
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.12f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = color)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("$count", style = MaterialTheme.typography.headlineSmall)
                Text(
                    label,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
