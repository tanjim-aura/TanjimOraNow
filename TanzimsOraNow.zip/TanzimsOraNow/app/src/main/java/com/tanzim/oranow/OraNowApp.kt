package com.tanzim.oranow

import android.app.Application
import com.tanzim.oranow.data.AppDatabase
import com.tanzim.oranow.data.SettingsStore
import com.tanzim.oranow.data.TaskRepository
import com.tanzim.oranow.reminders.NotificationHelper
import com.tanzim.oranow.reminders.ReminderScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class OraNowApp : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val database: AppDatabase by lazy { AppDatabase.build(this) }
    val scheduler: ReminderScheduler by lazy { ReminderScheduler(this) }
    val repository: TaskRepository by lazy { TaskRepository(database, scheduler) }
    val settings: SettingsStore by lazy { SettingsStore(this) }

    override fun onCreate() {
        super.onCreate()
        NotificationHelper.createChannel(this)
        // Keep alarms in sync (e.g. after the exact-alarm permission changes).
        appScope.launch(Dispatchers.IO) { repository.rescheduleAll() }
    }
}
