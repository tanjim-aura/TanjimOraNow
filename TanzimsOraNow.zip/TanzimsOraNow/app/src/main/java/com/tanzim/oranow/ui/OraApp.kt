package com.tanzim.oranow.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tanzim.oranow.data.TaskWithSubtasks
import com.tanzim.oranow.reminders.NotificationHelper
import com.tanzim.oranow.reminders.ReminderScheduler
import com.tanzim.oranow.ui.components.TaskActions
import com.tanzim.oranow.ui.screens.HomeScreen
import com.tanzim.oranow.ui.screens.SettingsSheet
import com.tanzim.oranow.ui.screens.StatsScreen
import com.tanzim.oranow.ui.screens.TaskEditorScreen
import com.tanzim.oranow.ui.screens.TasksScreen
import kotlinx.coroutines.launch

private data class TabItem(val label: String, val icon: ImageVector)

private val tabs = listOf(
    TabItem("Home", Icons.Rounded.Home),
    TabItem("Tasks", Icons.Rounded.CheckCircle),
    TabItem("Insights", Icons.Rounded.BarChart)
)

private const val TAB_HOME = 0
private const val TAB_TASKS = 1
private const val TAB_STATS = 2

@Composable
fun OraApp(vm: TaskViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    val themeMode by vm.themeMode.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    var tabIndex by rememberSaveable { mutableStateOf(TAB_HOME) }
    var sectionIndex by rememberSaveable { mutableStateOf(0) }
    val section = Section.entries[sectionIndex]

    var editorVisible by remember { mutableStateOf(false) }
    var editorItem by remember { mutableStateOf<TaskWithSubtasks?>(null) }
    var showSettings by remember { mutableStateOf(false) }

    // Permissions that affect reminders
    var notificationsEnabled by remember { mutableStateOf(NotificationHelper.canPostNotifications(context)) }
    var exactAlarmsAllowed by remember { mutableStateOf(ReminderScheduler.canScheduleExact(context)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        notificationsEnabled = NotificationHelper.canPostNotifications(context)
        exactAlarmsAllowed = ReminderScheduler.canScheduleExact(context)
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        notificationsEnabled = NotificationHelper.canPostNotifications(context)
    }
    val requestNotifications: () -> Unit = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !notificationsEnabled) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val openEditor: (TaskWithSubtasks?) -> Unit = { item ->
        editorItem = item
        editorVisible = true
    }

    val deleteWithUndo: (TaskWithSubtasks) -> Unit = { item ->
        vm.delete(item)
        editorVisible = false
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            val result = snackbar.showSnackbar(
                message = "Task deleted",
                actionLabel = "Undo",
                duration = SnackbarDuration.Short
            )
            if (result == SnackbarResult.ActionPerformed) vm.restore(item)
        }
    }

    val actions = remember(vm) {
        TaskActions(
            onToggle = { vm.toggleComplete(it) },
            onEdit = { openEditor(it) },
            onDelete = { deleteWithUndo(it) },
            onToggleSubtask = { vm.toggleSubtask(it) }
        )
    }

    BackHandler(enabled = editorVisible) { editorVisible = false }
    BackHandler(enabled = !editorVisible && tabIndex != TAB_HOME) { tabIndex = TAB_HOME }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            snackbarHost = { SnackbarHost(snackbar) },
            floatingActionButton = {
                if (tabIndex != TAB_STATS) {
                    ExtendedFloatingActionButton(
                        text = { Text("New task") },
                        icon = { Icon(Icons.Rounded.Add, contentDescription = null) },
                        onClick = { openEditor(null) },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                }
            },
            bottomBar = {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                    tabs.forEachIndexed { index, tab ->
                        NavigationBarItem(
                            selected = tabIndex == index,
                            onClick = { tabIndex = index },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label) }
                        )
                    }
                }
            }
        ) { padding ->
            AnimatedContent(
                targetState = tabIndex,
                transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(160)) },
                label = "tabs"
            ) { index ->
                when (index) {
                    TAB_HOME -> HomeScreen(
                        state = state,
                        actions = actions,
                        onOpenSection = {
                            sectionIndex = it.ordinal
                            tabIndex = TAB_TASKS
                        },
                        onOpenSettings = { showSettings = true },
                        padding = padding
                    )

                    TAB_TASKS -> TasksScreen(
                        state = state,
                        section = section,
                        onSectionChange = { sectionIndex = it.ordinal },
                        actions = actions,
                        padding = padding
                    )

                    else -> StatsScreen(state = state, padding = padding)
                }
            }
        }

        AnimatedVisibility(
            visible = editorVisible,
            enter = slideInVertically(tween(320)) { it } + fadeIn(tween(200)),
            exit = slideOutVertically(tween(260)) { it } + fadeOut(tween(200))
        ) {
            TaskEditorScreen(
                existing = editorItem,
                onClose = { editorVisible = false },
                onSave = { task, subtasks ->
                    vm.save(task, subtasks)
                    editorVisible = false
                },
                onDelete = deleteWithUndo,
                onReminderChosen = requestNotifications
            )
        }
    }

    if (showSettings) {
        SettingsSheet(
            themeMode = themeMode,
            onThemeChange = vm::setTheme,
            notificationsEnabled = notificationsEnabled,
            exactAlarmsAllowed = exactAlarmsAllowed,
            onEnableNotifications = requestNotifications,
            onDismiss = { showSettings = false }
        )
    }
}
