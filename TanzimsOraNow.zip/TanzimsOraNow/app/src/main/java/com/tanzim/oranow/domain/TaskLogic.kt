package com.tanzim.oranow.domain

import com.tanzim.oranow.data.Category
import com.tanzim.oranow.data.Priority
import com.tanzim.oranow.data.TaskWithSubtasks
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale

data class Buckets(
    val overdue: List<TaskWithSubtasks>,
    val today: List<TaskWithSubtasks>,
    val upcoming: List<TaskWithSubtasks>,
    val completed: List<TaskWithSubtasks>
) {
    companion object {
        val EMPTY = Buckets(emptyList(), emptyList(), emptyList(), emptyList())
    }
}

data class DailyProgress(val done: Int, val total: Int) {
    val fraction: Float get() = if (total == 0) 0f else done.toFloat() / total
}

data class DayCount(val date: LocalDate, val count: Int)

data class Stats(
    val total: Int,
    val completed: Int,
    val open: Int,
    val overdue: Int,
    val completionRate: Float,
    val completedLast7Days: Int,
    val streak: Int,
    val last7: List<DayCount>,
    val byCategory: List<Pair<Category, Int>>,
    val openByPriority: Map<Priority, Int>,
    val subtasksDone: Int,
    val subtasksTotal: Int
) {
    companion object {
        val EMPTY = Stats(
            total = 0, completed = 0, open = 0, overdue = 0, completionRate = 0f,
            completedLast7Days = 0, streak = 0, last7 = emptyList(), byCategory = emptyList(),
            openByPriority = emptyMap(), subtasksDone = 0, subtasksTotal = 0
        )
    }
}

/** Pure, Android-free task rules so they can be unit-tested on the JVM. */
object TaskLogic {

    val DEFAULT_REMINDER_TIME: LocalTime = LocalTime.of(9, 0)
    val END_OF_DAY: LocalTime = LocalTime.of(23, 59, 59)

    /** Reminder choices in minutes before the due time. */
    val REMINDER_OFFSETS = listOf(0, 10, 60, 1440)

    fun reminderLabel(offsetMin: Int?): String = when (offsetMin) {
        null -> "None"
        0 -> "At due time"
        10 -> "10 min before"
        60 -> "1 hour before"
        1440 -> "1 day before"
        else -> "$offsetMin min before"
    }

    fun toLocalDate(millis: Long, zone: ZoneId): LocalDate =
        Instant.ofEpochMilli(millis).atZone(zone).toLocalDate()

    fun computeDueAt(date: LocalDate?, time: LocalTime?, zone: ZoneId): Long? =
        date?.atTime(time ?: END_OF_DAY)?.atZone(zone)?.toInstant()?.toEpochMilli()

    fun computeRemindAt(date: LocalDate?, time: LocalTime?, offsetMin: Int?, zone: ZoneId): Long? {
        if (date == null || offsetMin == null) return null
        val base = date.atTime(time ?: DEFAULT_REMINDER_TIME).atZone(zone).toInstant().toEpochMilli()
        return base - offsetMin * 60_000L
    }

    fun isOverdue(dueAt: Long?, isCompleted: Boolean, now: Long): Boolean =
        !isCompleted && dueAt != null && dueAt < now

    fun bucketize(all: List<TaskWithSubtasks>, now: Long, zone: ZoneId): Buckets {
        val today = toLocalDate(now, zone)
        val completed = all.filter { it.task.isCompleted }
            .sortedByDescending { it.task.completedAt ?: 0L }
        val open = all.filter { !it.task.isCompleted }

        val overdue = open.filter { (it.task.dueAt ?: Long.MAX_VALUE) < now }
            .sortedBy { it.task.dueAt }
        val dueToday = open.filter {
            val due = it.task.dueAt
            due != null && due >= now && toLocalDate(due, zone) == today
        }.sortedWith(
            compareBy<TaskWithSubtasks> { it.task.dueAt ?: Long.MAX_VALUE }
                .thenByDescending { it.task.priority.rank }
        )
        val upcoming = open.filter {
            val due = it.task.dueAt
            due == null || (due >= now && toLocalDate(due, zone) > today)
        }.sortedWith(
            compareBy<TaskWithSubtasks> { it.task.dueAt ?: Long.MAX_VALUE }
                .thenByDescending { it.task.priority.rank }
        )
        return Buckets(overdue = overdue, today = dueToday, upcoming = upcoming, completed = completed)
    }

    /**
     * Today's progress: every task due today plus anything completed today (even if it had a
     * different or no due date), so finishing work always moves the ring forward.
     */
    fun dailyProgress(all: List<TaskWithSubtasks>, now: Long, zone: ZoneId): DailyProgress {
        val today = toLocalDate(now, zone)
        val relevant = all.filter {
            val due = it.task.dueAt
            val doneAt = it.task.completedAt
            (due != null && toLocalDate(due, zone) == today) ||
                (it.task.isCompleted && doneAt != null && toLocalDate(doneAt, zone) == today)
        }
        return DailyProgress(done = relevant.count { it.task.isCompleted }, total = relevant.size)
    }

    fun stats(all: List<TaskWithSubtasks>, now: Long, zone: ZoneId): Stats {
        if (all.isEmpty()) return Stats.EMPTY
        val today = toLocalDate(now, zone)
        val completed = all.filter { it.task.isCompleted }
        val open = all.filter { !it.task.isCompleted }

        val perDay: Map<LocalDate, Int> = completed
            .mapNotNull { it.task.completedAt?.let { c -> toLocalDate(c, zone) } }
            .groupingBy { it }
            .eachCount()

        val last7 = (6 downTo 0).map { offset ->
            val d = today.minusDays(offset.toLong())
            DayCount(d, perDay[d] ?: 0)
        }

        var streak = 0
        var cursor = if (perDay.containsKey(today)) today else today.minusDays(1)
        while (perDay.containsKey(cursor)) {
            streak++
            cursor = cursor.minusDays(1)
        }

        val byCategory = all.groupingBy { it.task.category }.eachCount()
            .entries.sortedByDescending { it.value }
            .map { it.key to it.value }

        val openByPriority = Priority.entries.associateWith { p -> open.count { it.task.priority == p } }
        val allSubtasks = all.flatMap { it.subtasks }

        return Stats(
            total = all.size,
            completed = completed.size,
            open = open.size,
            overdue = open.count { isOverdue(it.task.dueAt, false, now) },
            completionRate = completed.size.toFloat() / all.size,
            completedLast7Days = last7.sumOf { it.count },
            streak = streak,
            last7 = last7,
            byCategory = byCategory,
            openByPriority = openByPriority,
            subtasksDone = allSubtasks.count { it.isDone },
            subtasksTotal = allSubtasks.size
        )
    }

    fun matches(item: TaskWithSubtasks, query: String): Boolean {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return true
        val t = item.task
        return t.title.lowercase().contains(q) ||
            t.notes.lowercase().contains(q) ||
            t.category.label.lowercase().contains(q) ||
            t.priority.label.lowercase().contains(q) ||
            item.subtasks.any { it.title.lowercase().contains(q) }
    }

    /** "Today · 5:30 PM", "Tomorrow", "Mon, Oct 20", ... */
    fun dueLabel(
        dueAt: Long,
        hasTime: Boolean,
        now: Long,
        zone: ZoneId,
        locale: Locale = Locale.getDefault()
    ): String {
        val today = toLocalDate(now, zone)
        val dateTime = Instant.ofEpochMilli(dueAt).atZone(zone)
        val date = dateTime.toLocalDate()
        val dayPart = when (date) {
            today -> "Today"
            today.plusDays(1) -> "Tomorrow"
            today.minusDays(1) -> "Yesterday"
            else -> date.format(
                DateTimeFormatter.ofPattern(
                    if (date.year == today.year) "EEE, MMM d" else "MMM d, yyyy",
                    locale
                )
            )
        }
        if (!hasTime) return dayPart
        val timePart = dateTime.toLocalTime()
            .format(DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT).withLocale(locale))
        return "$dayPart · $timePart"
    }
}
