package com.tanzim.oranow.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DateRange
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Today
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tanzim.oranow.data.TaskWithSubtasks
import com.tanzim.oranow.domain.TaskLogic
import com.tanzim.oranow.ui.Section
import com.tanzim.oranow.ui.UiState
import com.tanzim.oranow.ui.components.ContentFrame
import com.tanzim.oranow.ui.components.EmptyState
import com.tanzim.oranow.ui.components.TaskActions
import com.tanzim.oranow.ui.components.TaskCard
import com.tanzim.oranow.ui.items

@Composable
fun TasksScreen(
    state: UiState,
    section: Section,
    onSectionChange: (Section) -> Unit,
    actions: TaskActions,
    padding: PaddingValues
) {
    var query by rememberSaveable { mutableStateOf("") }
    val searching = query.isNotBlank()

    val results = remember(query, state.all) {
        if (!searching) {
            emptyList()
        } else {
            state.all
                .filter { TaskLogic.matches(it, query) }
                .sortedWith(
                    compareBy<TaskWithSubtasks> { it.task.isCompleted }
                        .thenBy { it.task.dueAt ?: Long.MAX_VALUE }
                )
        }
    }
    val list = if (searching) results else section.items(state.buckets)

    ContentFrame {
        Column(
            Modifier
                .fillMaxSize()
                .padding(top = padding.calculateTopPadding() + 12.dp)
        ) {
            Text(
                "Tasks",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(horizontal = 20.dp)
            )
            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                placeholder = { Text("Search tasks, notes, subtasks") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                trailingIcon = {
                    if (searching) {
                        IconButton(onClick = { query = "" }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Clear search")
                        }
                    }
                },
                singleLine = true,
                shape = MaterialTheme.shapes.extraLarge,
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainer,
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceContainer,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                )
            )
            Spacer(Modifier.height(10.dp))

            LazyRow(
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(Section.entries.toList()) { s ->
                    val count = s.items(state.buckets).size
                    val accent = if (s == Section.Overdue && count > 0) {
                        MaterialTheme.colorScheme.error
                    } else {
                        MaterialTheme.colorScheme.primary
                    }
                    FilterChip(
                        selected = !searching && s == section,
                        onClick = {
                            query = ""
                            onSectionChange(s)
                        },
                        label = { Text("${s.label}  $count") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = accent.copy(alpha = 0.16f),
                            selectedLabelColor = accent
                        )
                    )
                }
            }
            Spacer(Modifier.height(8.dp))

            LazyColumn(
                Modifier.weight(1f),
                contentPadding = PaddingValues(
                    start = 20.dp,
                    end = 20.dp,
                    top = 4.dp,
                    bottom = padding.calculateBottomPadding() + 96.dp
                ),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (searching) {
                    item(key = "results-header") {
                        Text(
                            if (results.size == 1) "1 result" else "${results.size} results",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                if (list.isEmpty()) {
                    item(key = "empty") {
                        val (icon, title, message) = when {
                            searching -> Triple(Icons.Rounded.Search, "No matches", "Try a different word.")
                            section == Section.Today -> Triple(
                                Icons.Rounded.Today, "Nothing due today", "Add a task or check Upcoming."
                            )
                            section == Section.Upcoming -> Triple(
                                Icons.Rounded.DateRange, "Nothing scheduled", "Tasks with a later due date show up here."
                            )
                            section == Section.Completed -> Triple(
                                Icons.Rounded.CheckCircle, "Nothing completed yet", "Finished tasks are collected here."
                            )
                            else -> Triple(
                                Icons.Rounded.Warning, "You’re all caught up", "No task is past its due time."
                            )
                        }
                        EmptyState(icon = icon, title = title, message = message)
                    }
                } else {
                    items(list, key = { it.task.id }) { item ->
                        TaskCard(
                            item = item,
                            now = state.now,
                            onToggle = { actions.onToggle(item) },
                            onClick = { actions.onEdit(item) },
                            onDelete = { actions.onDelete(item) },
                            onToggleSubtask = actions.onToggleSubtask,
                            modifier = Modifier.animateItem()
                        )
                    }
                }
            }
        }
    }
}
