@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.tanzim.oranow.ui.screens

import android.text.format.DateFormat
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DateRange
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.AccessTime
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.tanzim.oranow.data.Category
import com.tanzim.oranow.data.Priority
import com.tanzim.oranow.data.SubtaskEntity
import com.tanzim.oranow.data.TaskEntity
import com.tanzim.oranow.data.TaskWithSubtasks
import com.tanzim.oranow.domain.TaskLogic
import com.tanzim.oranow.ui.color
import com.tanzim.oranow.ui.icon
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

private data class SubtaskDraft(val title: String, val done: Boolean)

@Composable
fun TaskEditorScreen(
    existing: TaskWithSubtasks?,
    onClose: () -> Unit,
    onSave: (TaskEntity, List<SubtaskEntity>) -> Unit,
    onDelete: ((TaskWithSubtasks) -> Unit)?,
    onReminderChosen: () -> Unit
) {
    val zone = remember { ZoneId.systemDefault() }
    val base = existing?.task

    var title by remember { mutableStateOf(base?.title ?: "") }
    var titleError by remember { mutableStateOf(false) }
    var notes by remember { mutableStateOf(base?.notes ?: "") }
    var priority by remember { mutableStateOf(base?.priority ?: Priority.MEDIUM) }
    var category by remember { mutableStateOf(base?.category ?: Category.PERSONAL) }
    var date by remember {
        mutableStateOf(base?.dueAt?.let { TaskLogic.toLocalDate(it, zone) })
    }
    var time by remember {
        mutableStateOf(
            if (base != null && base.hasDueTime) {
                base.dueAt?.let {
                    Instant.ofEpochMilli(it).atZone(zone).toLocalTime().withSecond(0).withNano(0)
                }
            } else {
                null
            }
        )
    }
    var reminder by remember { mutableStateOf(base?.reminderOffsetMin) }
    val subtasks = remember {
        mutableStateListOf<SubtaskDraft>().apply {
            existing?.subtasks?.sortedBy { it.position }?.forEach { add(SubtaskDraft(it.title, it.isDone)) }
        }
    }
    var newSubtask by remember { mutableStateOf("") }
    var showDatePicker by remember { mutableStateOf(false) }
    var showTimePicker by remember { mutableStateOf(false) }

    val today = LocalDate.now(zone)
    val tomorrow = today.plusDays(1)
    val nextWeek = today.plusDays(7)
    val remindAtPreview = TaskLogic.computeRemindAt(date, time, reminder, zone)
    val reminderInPast = remindAtPreview != null && remindAtPreview <= System.currentTimeMillis()

    fun addSubtask() {
        val text = newSubtask.trim()
        if (text.isNotEmpty()) {
            subtasks.add(SubtaskDraft(text, false))
            newSubtask = ""
        }
    }

    fun save() {
        val trimmed = title.trim()
        if (trimmed.isEmpty()) {
            titleError = true
            return
        }
        addSubtask() // don't lose a subtask that was typed but not yet added
        val reminderOffset = if (date != null) reminder else null
        val entity = TaskEntity(
            id = base?.id ?: 0L,
            title = trimmed,
            notes = notes.trim(),
            priority = priority,
            category = category,
            dueAt = TaskLogic.computeDueAt(date, time, zone),
            hasDueTime = date != null && time != null,
            reminderOffsetMin = reminderOffset,
            remindAt = TaskLogic.computeRemindAt(date, time, reminderOffset, zone),
            isCompleted = base?.isCompleted ?: false,
            completedAt = base?.completedAt,
            createdAt = base?.createdAt ?: System.currentTimeMillis()
        )
        val subtaskEntities = subtasks.mapIndexed { index, draft ->
            SubtaskEntity(
                taskId = base?.id ?: 0L,
                title = draft.title,
                isDone = draft.done,
                position = index
            )
        }
        onSave(entity, subtaskEntities)
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {}, // swallow touches so nothing underneath reacts
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(if (existing == null) "New task" else "Edit task") },
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Close editor")
                    }
                },
                actions = {
                    Button(onClick = { save() }, modifier = Modifier.padding(end = 12.dp)) {
                        Text("Save")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .consumeWindowInsets(padding)
                .imePadding()
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = {
                    title = it
                    if (it.isNotBlank()) titleError = false
                },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Task title") },
                isError = titleError,
                supportingText = { if (titleError) Text("Please enter a title") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences)
            )
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Notes (optional)") },
                minLines = 2,
                maxLines = 5,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences)
            )

            FieldLabel("Priority")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Priority.entries.forEach { p ->
                    FilterChip(
                        selected = priority == p,
                        onClick = { priority = p },
                        label = { Text(p.label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = p.color().copy(alpha = 0.2f),
                            selectedLabelColor = p.color()
                        )
                    )
                }
            }

            FieldLabel("Category")
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Category.entries.forEach { c ->
                    FilterChip(
                        selected = category == c,
                        onClick = { category = c },
                        label = { Text(c.label) },
                        leadingIcon = {
                            Icon(c.icon(), contentDescription = null, modifier = Modifier.size(FilterChipDefaults.IconSize))
                        }
                    )
                }
            }

            FieldLabel("Due date")
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                FilterChip(selected = date == today, onClick = { date = today }, label = { Text("Today") })
                FilterChip(selected = date == tomorrow, onClick = { date = tomorrow }, label = { Text("Tomorrow") })
                FilterChip(selected = date == nextWeek, onClick = { date = nextWeek }, label = { Text("Next week") })
                val custom = date != null && date != today && date != tomorrow && date != nextWeek
                FilterChip(
                    selected = custom,
                    onClick = { showDatePicker = true },
                    label = {
                        Text(
                            if (custom) {
                                date!!.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM))
                            } else {
                                "Pick date"
                            }
                        )
                    },
                    leadingIcon = {
                        Icon(Icons.Rounded.DateRange, contentDescription = null, modifier = Modifier.size(FilterChipDefaults.IconSize))
                    }
                )
            }
            if (date != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { showTimePicker = true }) {
                        Icon(Icons.Rounded.AccessTime, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            time?.format(DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT)) ?: "Add time"
                        )
                    }
                    if (time != null) {
                        IconButton(onClick = { time = null }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Remove time")
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = {
                        date = null
                        time = null
                        reminder = null
                    }) { Text("Clear date") }
                }
            }

            FieldLabel("Reminder")
            if (date == null) {
                Text(
                    "Choose a due date to enable reminders.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    FilterChip(
                        selected = reminder == null,
                        onClick = { reminder = null },
                        label = { Text(TaskLogic.reminderLabel(null)) }
                    )
                    TaskLogic.REMINDER_OFFSETS.forEach { offset ->
                        FilterChip(
                            selected = reminder == offset,
                            onClick = {
                                reminder = offset
                                onReminderChosen()
                            },
                            label = { Text(TaskLogic.reminderLabel(offset)) }
                        )
                    }
                }
                if (reminder != null && time == null) {
                    Text(
                        "No time set, so the reminder is based on 9:00 AM.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (reminderInPast) {
                    Text(
                        "That reminder time has already passed, so no notification will be sent.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }

            FieldLabel("Subtasks")
            subtasks.forEachIndexed { index, draft ->
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = draft.done,
                        onCheckedChange = { subtasks[index] = draft.copy(done = it) }
                    )
                    Text(
                        draft.title,
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodyLarge
                    )
                    IconButton(onClick = { subtasks.removeAt(index) }) {
                        Icon(Icons.Rounded.Close, contentDescription = "Remove subtask")
                    }
                }
            }
            OutlinedTextField(
                value = newSubtask,
                onValueChange = { newSubtask = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Add a subtask") },
                singleLine = true,
                trailingIcon = {
                    IconButton(onClick = { addSubtask() }, enabled = newSubtask.isNotBlank()) {
                        Icon(Icons.Rounded.Add, contentDescription = "Add subtask")
                    }
                },
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Sentences,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(onDone = { addSubtask() })
            )

            if (existing != null && onDelete != null) {
                Spacer(Modifier.height(12.dp))
                OutlinedButton(
                    onClick = { onDelete(existing) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(Icons.Rounded.Delete, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Delete task")
                }
            }
            Spacer(Modifier.height(32.dp))
        }
    }

    if (showDatePicker) {
        val pickerState = rememberDatePickerState(
            initialSelectedDateMillis = date?.atStartOfDay(ZoneOffset.UTC)?.toInstant()?.toEpochMilli()
        )
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    pickerState.selectedDateMillis?.let { millis ->
                        date = Instant.ofEpochMilli(millis).atZone(ZoneOffset.UTC).toLocalDate()
                    }
                    showDatePicker = false
                }) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) { Text("Cancel") }
            }
        ) {
            DatePicker(state = pickerState)
        }
    }

    if (showTimePicker) {
        TimePickerDialog(
            initial = time ?: TaskLogic.DEFAULT_REMINDER_TIME,
            onDismiss = { showTimePicker = false },
            onConfirm = {
                time = it
                showTimePicker = false
            }
        )
    }
}

@Composable
private fun FieldLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 10.dp)
    )
}

@Composable
private fun TimePickerDialog(
    initial: LocalTime,
    onDismiss: () -> Unit,
    onConfirm: (LocalTime) -> Unit
) {
    val context = LocalContext.current
    val state = rememberTimePickerState(
        initialHour = initial.hour,
        initialMinute = initial.minute,
        is24Hour = DateFormat.is24HourFormat(context)
    )
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = MaterialTheme.shapes.extraLarge,
            tonalElevation = 6.dp,
            modifier = Modifier
                .width(IntrinsicSize.Min)
                .height(IntrinsicSize.Min)
        ) {
            Column(Modifier.padding(24.dp)) {
                Text(
                    "Select time",
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 20.dp)
                )
                TimePicker(state = state)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    TextButton(onClick = { onConfirm(LocalTime.of(state.hour, state.minute)) }) { Text("OK") }
                }
            }
        }
    }
}
