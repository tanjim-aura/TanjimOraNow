package com.tanzim.oranow.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.tanzim.oranow.data.Category
import com.tanzim.oranow.data.Priority
import com.tanzim.oranow.domain.Stats
import com.tanzim.oranow.ui.UiState
import com.tanzim.oranow.ui.color
import com.tanzim.oranow.ui.components.ContentFrame
import com.tanzim.oranow.ui.components.EmptyState
import com.tanzim.oranow.ui.components.ProgressRing
import com.tanzim.oranow.ui.components.rememberAppeared
import com.tanzim.oranow.ui.icon
import java.time.format.TextStyle as DayTextStyle
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

@Composable
fun StatsScreen(state: UiState, padding: PaddingValues) {
    val stats = state.stats

    ContentFrame {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 20.dp,
                end = 20.dp,
                top = padding.calculateTopPadding() + 12.dp,
                bottom = padding.calculateBottomPadding() + 24.dp
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item(key = "title") {
                Column {
                    Text("Insights", style = MaterialTheme.typography.headlineMedium)
                    Text(
                        "Your productivity at a glance",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            if (stats.total == 0) {
                item(key = "empty") {
                    EmptyState(
                        icon = Icons.Rounded.BarChart,
                        title = "No data yet",
                        message = "Add and complete a few tasks and your statistics will appear here."
                    )
                }
            } else {
                item(key = "overview") { OverviewCard(stats) }
                item(key = "week") { WeekChart(stats) }
                item(key = "categories") { CategoryCard(stats) }
                item(key = "priority") { PriorityCard(stats) }
            }
        }
    }
}

@Composable
private fun StatsCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(Modifier.padding(18.dp), content = content)
    }
}

@Composable
private fun OverviewCard(stats: Stats) {
    StatsCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ProgressRing(
                progress = stats.completionRate,
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                diameter = 96.dp,
                strokeWidth = 10.dp
            ) {
                Text(
                    "${(stats.completionRate * 100).roundToInt()}%",
                    style = MaterialTheme.typography.titleLarge
                )
            }
            Spacer(Modifier.width(18.dp))
            Column {
                Text("Completion rate", style = MaterialTheme.typography.titleMedium)
                Text(
                    "${stats.completed} of ${stats.total} tasks completed",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (stats.subtasksTotal > 0) {
                    Text(
                        "${stats.subtasksDone}/${stats.subtasksTotal} subtasks done",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Row {
            MiniStat("${stats.open}", "Open", Modifier.weight(1f))
            MiniStat("${stats.overdue}", "Overdue", Modifier.weight(1f), if (stats.overdue > 0) MaterialTheme.colorScheme.error else null)
            MiniStat("${stats.streak}", "Day streak", Modifier.weight(1f))
            MiniStat("${stats.completedLast7Days}", "Last 7 days", Modifier.weight(1f))
        }
    }
}

@Composable
private fun MiniStat(value: String, label: String, modifier: Modifier = Modifier, valueColor: Color? = null) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            value,
            style = MaterialTheme.typography.titleLarge,
            color = valueColor ?: MaterialTheme.colorScheme.onSurface
        )
        Text(
            label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun WeekChart(stats: Stats) {
    val maxCount = max(1, stats.last7.maxOfOrNull { it.count } ?: 1)
    StatsCard {
        Text("Completed, last 7 days", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(14.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .height(150.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            stats.last7.forEachIndexed { index, day ->
                val appeared = rememberAppeared()
                val target = if (appeared) max(day.count.toFloat() / maxCount, 0.04f) else 0f
                val fraction by animateFloatAsState(
                    targetValue = target,
                    animationSpec = tween(700, delayMillis = index * 60, easing = FastOutSlowInEasing),
                    label = "bar$index"
                )
                val isToday = index == stats.last7.lastIndex
                Column(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        if (day.count > 0) "${day.count}" else "",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Box(
                        Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        Box(
                            Modifier
                                .width(22.dp)
                                .fillMaxHeight(fraction.coerceIn(0f, 1f))
                                .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp, bottomStart = 3.dp, bottomEnd = 3.dp))
                                .background(
                                    if (day.count == 0) {
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                                    } else if (isToday) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)
                                    }
                                )
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        day.date.dayOfWeek.getDisplayName(DayTextStyle.SHORT, Locale.getDefault()),
                        style = MaterialTheme.typography.labelMedium,
                        color = if (isToday) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun CategoryCard(stats: Stats) {
    val maxCount = max(1, stats.byCategory.maxOfOrNull { it.second } ?: 1)
    StatsCard {
        Text("By category", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(12.dp))
        stats.byCategory.forEach { (category, count) ->
            CategoryRow(category, count, count.toFloat() / maxCount)
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun CategoryRow(category: Category, count: Int, fraction: Float) {
    val appeared = rememberAppeared()
    val animated by animateFloatAsState(
        targetValue = if (appeared) fraction else 0f,
        animationSpec = tween(800, easing = FastOutSlowInEasing),
        label = "category"
    )
    val color = category.color()
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(category.icon(), contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(category.label, style = MaterialTheme.typography.labelLarge)
                Text("$count", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { animated },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp),
                color = color,
                trackColor = color.copy(alpha = 0.15f)
            )
        }
    }
}

@Composable
private fun PriorityCard(stats: Stats) {
    StatsCard {
        Text("Open tasks by priority", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf(Priority.HIGH, Priority.MEDIUM, Priority.LOW).forEach { priority ->
                val color = priority.color()
                Column(
                    Modifier
                        .weight(1f)
                        .clip(MaterialTheme.shapes.medium)
                        .background(color.copy(alpha = 0.12f))
                        .padding(vertical = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("${stats.openByPriority[priority] ?: 0}", style = MaterialTheme.typography.headlineSmall, color = color)
                    Text(priority.label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
