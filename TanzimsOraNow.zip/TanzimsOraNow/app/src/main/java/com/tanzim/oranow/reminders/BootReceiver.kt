package com.tanzim.oranow.reminders

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.tanzim.oranow.OraNowApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Alarms are wiped by a reboot or app update, so rebuild them from the database. */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED &&
            intent.action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) return

        val app = context.applicationContext as OraNowApp
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                app.repository.rescheduleAll()
            } finally {
                pending.finish()
            }
        }
    }
}
