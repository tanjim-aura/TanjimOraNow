package com.tanzim.oranow.data

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation

enum class Priority(val label: String, val rank: Int) {
    LOW("Low", 0),
    MEDIUM("Medium", 1),
    HIGH("High", 2)
}

enum class Category(val label: String) {
    PERSONAL("Personal"),
    WORK("Work"),
    STUDY("Study"),
    HEALTH("Health"),
    SHOPPING("Shopping"),
    FINANCE("Finance"),
    OTHER("Other")
}

/**
 * A task. [dueAt] is an epoch-millis instant. When the user picks a date without a time,
 * [dueAt] is that day at 23:59:59 local time and [hasDueTime] is false.
 * [reminderOffsetMin] is "minutes before the due time" (null = no reminder) and [remindAt]
 * is the resulting absolute trigger instant.
 */
@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val notes: String = "",
    val priority: Priority = Priority.MEDIUM,
    val category: Category = Category.PERSONAL,
    val dueAt: Long? = null,
    val hasDueTime: Boolean = false,
    val reminderOffsetMin: Int? = null,
    val remindAt: Long? = null,
    val isCompleted: Boolean = false,
    val completedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "subtasks",
    foreignKeys = [
        ForeignKey(
            entity = TaskEntity::class,
            parentColumns = ["id"],
            childColumns = ["taskId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("taskId")]
)
data class SubtaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val taskId: Long,
    val title: String,
    val isDone: Boolean = false,
    val position: Int = 0
)

data class TaskWithSubtasks(
    @Embedded val task: TaskEntity,
    @Relation(parentColumn = "id", entityColumn = "taskId")
    val subtasks: List<SubtaskEntity>
)
