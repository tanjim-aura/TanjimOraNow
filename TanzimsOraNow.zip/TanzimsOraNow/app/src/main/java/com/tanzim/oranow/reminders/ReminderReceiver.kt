package com.tanzim.oranow.reminders

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.tanzim.oranow.domain.TaskLogic
import java.time.ZoneId

class ReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getLongExtra(EXTRA_TASK_ID, -1L)
        if (taskId < 0) return

        val title = intent.getStringExtra(EXTRA_TITLE)?.takeIf { it.isNotBlank() } ?: "Task reminder"
        val dueAt = intent.getLongExtra(EXTRA_DUE_AT, -1L)
        val hasTime = intent.getBooleanExtra(EXTRA_HAS_TIME, false)

        val body = if (dueAt > 0) {
            "Due " + TaskLogic.dueLabel(dueAt, hasTime, System.currentTimeMillis(), ZoneId.systemDefault())
        } else {
            "Don't forget this one."
        }
        NotificationHelper.showReminder(context, taskId, title, body)
    }

    companion object {
        const val EXTRA_TASK_ID = "task_id"
        const val EXTRA_TITLE = "title"
        const val EXTRA_DUE_AT = "due_at"
        const val EXTRA_HAS_TIME = "has_time"
    }
}
