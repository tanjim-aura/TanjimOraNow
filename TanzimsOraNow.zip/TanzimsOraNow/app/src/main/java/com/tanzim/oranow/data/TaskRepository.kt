package com.tanzim.oranow.data

import androidx.room.withTransaction
import com.tanzim.oranow.reminders.ReminderScheduler
import kotlinx.coroutines.flow.Flow

class TaskRepository(
    private val db: AppDatabase,
    private val scheduler: ReminderScheduler
) {
    private val dao = db.taskDao()

    val tasks: Flow<List<TaskWithSubtasks>> = dao.observeAll()

    /** Inserts or updates a task together with its subtasks and (re)schedules its reminder. */
    suspend fun save(task: TaskEntity, subtasks: List<SubtaskEntity>): Long {
        val id = db.withTransaction {
            val savedId = dao.upsertTask(task)
            dao.deleteSubtasksFor(savedId)
            dao.insertSubtasks(subtasks.map { it.copy(id = 0, taskId = savedId) })
            savedId
        }
        scheduler.schedule(task.copy(id = id))
        return id
    }

    suspend fun setCompleted(id: Long, done: Boolean) {
        dao.setCompleted(id, done, if (done) System.currentTimeMillis() else null)
        if (done) {
            scheduler.cancel(id)
        } else {
            dao.getTask(id)?.let { scheduler.schedule(it) }
        }
    }

    suspend fun delete(id: Long) {
        scheduler.cancel(id)
        dao.deleteTask(id)
    }

    /** Puts back a task (and its subtasks) that was just deleted, keeping the original ids. */
    suspend fun restore(item: TaskWithSubtasks) {
        db.withTransaction {
            dao.upsertTask(item.task)
            dao.insertSubtasks(item.subtasks)
        }
        scheduler.schedule(item.task)
    }

    suspend fun toggleSubtask(id: Long, done: Boolean) = dao.setSubtaskDone(id, done)

    /** Re-creates every pending alarm (after reboot, app update, or on app start). */
    suspend fun rescheduleAll() {
        dao.upcomingReminders(System.currentTimeMillis()).forEach { scheduler.schedule(it) }
    }
}
