package com.tanzim.oranow.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tanzim.oranow.OraNowApp
import com.tanzim.oranow.data.SubtaskEntity
import com.tanzim.oranow.data.TaskEntity
import com.tanzim.oranow.data.TaskWithSubtasks
import com.tanzim.oranow.data.ThemeMode
import com.tanzim.oranow.domain.Buckets
import com.tanzim.oranow.domain.DailyProgress
import com.tanzim.oranow.domain.Stats
import com.tanzim.oranow.domain.TaskLogic
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.ZoneId

data class UiState(
    val loaded: Boolean = false,
    val now: Long = System.currentTimeMillis(),
    val all: List<TaskWithSubtasks> = emptyList(),
    val buckets: Buckets = Buckets.EMPTY,
    val progress: DailyProgress = DailyProgress(0, 0),
    val stats: Stats = Stats.EMPTY
)

class TaskViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as OraNowApp
    private val repo = app.repository

    /** Emits the current time every 30s so "overdue" updates without any user action. */
    private val ticker = flow {
        while (true) {
            emit(System.currentTimeMillis())
            delay(30_000L)
        }
    }

    val state: StateFlow<UiState> = combine(repo.tasks, ticker) { tasks, now ->
        val zone = ZoneId.systemDefault()
        UiState(
            loaded = true,
            now = now,
            all = tasks,
            buckets = TaskLogic.bucketize(tasks, now, zone),
            progress = TaskLogic.dailyProgress(tasks, now, zone),
            stats = TaskLogic.stats(tasks, now, zone)
        )
    }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UiState())

    val themeMode: StateFlow<ThemeMode> = app.settings.themeMode
        .stateIn(viewModelScope, SharingStarted.Eagerly, ThemeMode.SYSTEM)

    fun save(task: TaskEntity, subtasks: List<SubtaskEntity>) {
        viewModelScope.launch { repo.save(task, subtasks) }
    }

    fun toggleComplete(item: TaskWithSubtasks) {
        viewModelScope.launch { repo.setCompleted(item.task.id, !item.task.isCompleted) }
    }

    fun delete(item: TaskWithSubtasks) {
        viewModelScope.launch { repo.delete(item.task.id) }
    }

    fun restore(item: TaskWithSubtasks) {
        viewModelScope.launch { repo.restore(item) }
    }

    fun toggleSubtask(subtask: SubtaskEntity) {
        viewModelScope.launch { repo.toggleSubtask(subtask.id, !subtask.isDone) }
    }

    fun setTheme(mode: ThemeMode) {
        viewModelScope.launch { app.settings.setThemeMode(mode) }
    }
}
