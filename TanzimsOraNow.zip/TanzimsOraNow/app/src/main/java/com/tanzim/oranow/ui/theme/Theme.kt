package com.tanzim.oranow.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Brand gradient used by the dashboard hero card and the app icon. */
val BrandGradient = listOf(Color(0xFF5B4BDB), Color(0xFF8A5CF6), Color(0xFFD14FA0))

val PriorityHigh = Color(0xFFE5484D)
val PriorityMedium = Color(0xFFF5A524)
val PriorityLow = Color(0xFF30A46C)

private val LightColors = lightColorScheme(
    primary = Color(0xFF5B4BDB),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE5E0FF),
    onPrimaryContainer = Color(0xFF1B0A5E),
    secondary = Color(0xFF0F8F82),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFC8F3EC),
    onSecondaryContainer = Color(0xFF00201D),
    tertiary = Color(0xFFC2406F),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFD9E3),
    onTertiaryContainer = Color(0xFF3F001A),
    error = Color(0xFFD9363E),
    onError = Color.White,
    background = Color(0xFFF8F7FD),
    onBackground = Color(0xFF1C1B26),
    surface = Color(0xFFFCFBFF),
    onSurface = Color(0xFF1C1B26),
    surfaceVariant = Color(0xFFE9E6F5),
    onSurfaceVariant = Color(0xFF5A5770),
    outline = Color(0xFF8F8CA8),
    outlineVariant = Color(0xFFDDD9EE),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFFFFFFF),
    surfaceContainer = Color(0xFFF0EEFA),
    surfaceContainerHigh = Color(0xFFE9E6F5),
    surfaceContainerHighest = Color(0xFFE2DFF0)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFB3A8FF),
    onPrimary = Color(0xFF2A1A87),
    primaryContainer = Color(0xFF4332B8),
    onPrimaryContainer = Color(0xFFE5E0FF),
    secondary = Color(0xFF5ADBCB),
    onSecondary = Color(0xFF00382F),
    secondaryContainer = Color(0xFF00504A),
    onSecondaryContainer = Color(0xFFC8F3EC),
    tertiary = Color(0xFFFF9DBB),
    onTertiary = Color(0xFF5E1130),
    tertiaryContainer = Color(0xFF7A2848),
    onTertiaryContainer = Color(0xFFFFD9E3),
    error = Color(0xFFFF8A8F),
    onError = Color(0xFF5C0007),
    background = Color(0xFF0E0C16),
    onBackground = Color(0xFFE8E5F5),
    surface = Color(0xFF15131F),
    onSurface = Color(0xFFE8E5F5),
    surfaceVariant = Color(0xFF2A2740),
    onSurfaceVariant = Color(0xFFB0ACC8),
    outline = Color(0xFF77739A),
    outlineVariant = Color(0xFF2F2B47),
    surfaceContainerLowest = Color(0xFF100E19),
    surfaceContainerLow = Color(0xFF1A1827),
    surfaceContainer = Color(0xFF1F1C2E),
    surfaceContainerHigh = Color(0xFF282539),
    surfaceContainerHighest = Color(0xFF312D46)
)

private val AppTypography = Typography(
    headlineLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 32.sp, lineHeight = 38.sp, letterSpacing = (-0.5).sp),
    headlineMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 26.sp, lineHeight = 32.sp, letterSpacing = (-0.3).sp),
    headlineSmall = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 22.sp, lineHeight = 28.sp),
    titleLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 20.sp, lineHeight = 26.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp, letterSpacing = 0.1.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 20.sp, letterSpacing = 0.1.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = 0.3.sp)
)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(30.dp)
)

@Composable
fun OraNowTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        shapes = AppShapes,
        content = content
    )
}
