# Room, Compose and DataStore ship their own consumer rules.
# Add project-specific ProGuard/R8 rules below if needed.
