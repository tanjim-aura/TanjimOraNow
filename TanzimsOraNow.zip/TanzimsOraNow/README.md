# Tanzim’s Ora Now

A native Android to-do and productivity app. Kotlin, Jetpack Compose, Material 3, Room, DataStore.
Package: `com.tanzim.oranow` · minSdk 26 (Android 8.0) · targetSdk 35.

This is a real Android project, not a website or WebView wrapper.

## Build the APK

### Option A: Android Studio (easiest)
1. Install Android Studio (Ladybug 2024.2 or newer).
2. **File ▸ Open** and select this `TanzimsOraNow` folder. Let Gradle sync (it downloads the Android SDK platform 35 if missing).
3. **Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s)**.
4. The file is at `app/build/outputs/apk/debug/app-debug.apk`.
5. Copy it to your phone and open it (allow "install unknown apps"), or run it directly on a device or emulator with the green ▶ button.

### Option B: command line
Needs JDK 17+ and the Android SDK (`ANDROID_HOME` set, platform 35 and build-tools installed).

```bash
./gradlew testDebugUnitTest      # JVM unit tests for the task logic
./gradlew assembleDebug          # builds the APK
adb install -r app/build/outputs/apk/debug/app-debug.apk
```
On Windows use `gradlew.bat`.

### Option C: build in the cloud with GitHub Actions
Push this folder to a GitHub repository. `.github/workflows/build-apk.yml` runs the tests, builds the debug APK and attaches it to the run as an artifact.

## Features
- Dashboard with a daily progress ring, streak, quick counters and Needs attention / Today lists
- Add, edit, complete, delete (with Undo) and search tasks (title, notes, category, subtasks)
- Priorities (Low/Medium/High), 7 categories, due date and optional time, subtasks with progress
- Sections: Today, Upcoming, Completed, Overdue (overdue updates automatically as time passes)
- Insights: completion rate, 7-day chart, streak, category and priority breakdowns
- Local reminders through `AlarmManager` + notifications (exact when allowed, inexact fallback), restored after reboot
- Light, Dark and System themes (Settings ▸ gear icon on Home)
- Fully offline: all data in a local Room database, theme in DataStore
- Custom adaptive launcher icon (with Android 13 themed-icon layer)

## Permissions
| Permission | Why |
|---|---|
| `POST_NOTIFICATIONS` | Show reminders (asked when you pick a reminder; Android 13+) |
| `SCHEDULE_EXACT_ALARM` | Fire reminders at the exact minute; optional, Settings offers a shortcut |
| `RECEIVE_BOOT_COMPLETED` | Re-create reminders after the phone restarts |

## Project layout
```
app/src/main/java/com/tanzim/oranow/
  OraNowApp.kt            Application: database, repository, notification channel
  data/                   Room entities, DAO, database, repository, DataStore settings
  domain/TaskLogic.kt     Pure rules: buckets, progress, stats, search, date labels
  reminders/              Scheduler, receivers (alarm + boot), notification helper
  ui/                     MainActivity, OraApp (navigation shell), ViewModel
  ui/screens/             Home, Tasks, Insights, Task editor, Settings
  ui/components/          TaskCard, ProgressRing, shared widgets
  ui/theme/               Material 3 colours, typography, shapes
app/src/test/             JUnit tests for TaskLogic
```
